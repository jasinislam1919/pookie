/* ============================================================
   OUR SAFE HAVEN — script.js logic (inlined for single-file app)
   ============================================================ */

/* ---------- Mood Theme Engine ---------- */
const moodThemes = {
  default:{ '--bg-main':'#0d1220', '--bg-deep':'#070a12', '--accent':'#f6a8c2', '--accent-soft':'#f8c9db', '--accent-2':'#c9b8f5', '--card-border':'rgba(255,255,255,0.14)' },
  overwhelmed:{ '--bg-main':'#0a1a1c', '--bg-deep':'#060f11', '--accent':'#8fd9e0', '--accent-soft':'#c3edf0', '--accent-2':'#9fd8c9', '--card-border':'rgba(143,217,224,0.22)' },
  exhausted:{ '--bg-main':'#1c150b', '--bg-deep':'#120d06', '--accent':'#e9c98f', '--accent-soft':'#f3e0b8', '--accent-2':'#d9b389', '--card-border':'rgba(233,201,143,0.22)' },
  missing:{ '--bg-main':'#1a0f16', '--bg-deep':'#110a0f', '--accent':'#e8a6c4', '--accent-soft':'#f4cfe0', '--accent-2':'#d9a3c9', '--card-border':'rgba(232,166,196,0.24)' },
  sleep:{ '--bg-main':'#100c1e', '--bg-deep':'#0a0714', '--accent':'#b3a4e8', '--accent-soft':'#d9d0f5', '--accent-2':'#9a9de0', '--card-border':'rgba(179,164,232,0.24)' }
};

function applyMood(mood){
  const theme = moodThemes[mood] || moodThemes.default;
  const root = document.documentElement.style;
  Object.entries(theme).forEach(([k,v]) => root.setProperty(k, v));
  document.querySelectorAll('.mood-btn').forEach(b => b.classList.toggle('active', b.dataset.mood === mood));
}

document.getElementById('mood-grid').addEventListener('click', (e) => {
  const btn = e.target.closest('.mood-btn');
  if(!btn) return;
  applyMood(btn.dataset.mood);
});

/* ---------- Floating background hearts ---------- */
const heartField = document.getElementById('heart-field');
const heartGlyphs = ['💖','💕','💗','🤍','✨'];
function spawnHeart(){
  const h = document.createElement('div');
  h.className = 'floaty-heart';
  h.textContent = heartGlyphs[Math.floor(Math.random()*heartGlyphs.length)];
  const left = Math.random()*100;
  const duration = 9 + Math.random()*8;
  const size = 14 + Math.random()*16;
  const drift = (Math.random()*140 - 70) + 'px';
  h.style.left = left + 'vw';
  h.style.fontSize = size + 'px';
  h.style.animationDuration = duration + 's';
  h.style.setProperty('--drift', drift);
  heartField.appendChild(h);
  setTimeout(() => h.remove(), duration*1000 + 200);
}
for(let i=0;i<10;i++) setTimeout(spawnHeart, i*700);
setInterval(spawnHeart, 900);

/* ---------- Modal helpers ---------- */
const modalBackdrop = document.getElementById('modal-backdrop');
const modalTitle = document.getElementById('modal-title');
const modalBody = document.getElementById('modal-body');
const modalGif = document.getElementById('modal-gif');
const modalGifFallback = document.getElementById('modal-gif-fallback');
function openModal(title, body, gifUrl){
  modalTitle.textContent = title;
  modalBody.textContent = body;
  modalGif.style.display = 'none';
  modalGifFallback.style.display = 'none';
  if(gifUrl){
    modalGif.onload = () => {
      modalGif.style.display = 'block';
      modalGifFallback.style.display = 'none';
    };
    modalGif.onerror = () => {
      modalGif.style.display = 'none';
      modalGifFallback.style.display = 'flex';
    };
    // Show the charming fallback immediately so there's never a blank/broken gap,
    // then swap to the real gif the instant it successfully loads.
    modalGifFallback.style.display = 'flex';
    modalGif.src = gifUrl;
  }
  modalBackdrop.classList.add('show');
}
function closeModal(){ modalBackdrop.classList.remove('show'); }
document.getElementById('modal-close').addEventListener('click', closeModal);
modalBackdrop.addEventListener('click', (e) => { if(e.target === modalBackdrop) closeModal(); });
document.addEventListener('keydown', (e) => { if(e.key === 'Escape') closeModal(); });

/* ---------- Worry Dissolver ---------- */
const worryInput = document.getElementById('worry-input');
const releaseBtn = document.getElementById('release-btn');
const dissolveLayer = document.getElementById('dissolve-layer');

releaseBtn.addEventListener('click', () => {
  const text = worryInput.value.trim();
  if(!text){
    worryInput.focus();
    worryInput.placeholder = "Type something first, love... even one word 🤍";
    return;
  }
  const count = Math.min(28, Math.max(10, text.length));
  for(let i=0;i<count;i++){
    const p = document.createElement('div');
    p.className = 'dissolve-heart';
    p.textContent = ['💗','💕','🤍','✨'][Math.floor(Math.random()*4)];
    p.style.left = (10 + Math.random()*80) + '%';
    p.style.top = (20 + Math.random()*50) + '%';
    p.style.setProperty('--dx', (Math.random()*120 - 60) + 'px');
    p.style.animationDelay = (Math.random()*0.4) + 's';
    dissolveLayer.appendChild(p);
    setTimeout(() => p.remove(), 2200);
  }
  worryInput.value = '';
  worryInput.placeholder = "Type down whatever is stressing you out, Pookie... let it go here 🤍";
  setTimeout(() => {
    openModal("You're safe here 💕", "Your worries are gone now. You're safe here 💕\n\nWhatever it was, you don't have to carry it alone. Breathe, Pookie. I've got you.");
  }, 500);
});

/* ---------- Breathing Exercise ---------- */
const breatheCircle = document.getElementById('breathe-circle');
const breatheBtn = document.getElementById('breathe-btn');
let breathing = false;
let breatheTimer = null;
let breathePhaseIndex = 0;
const phases = [
  { label:'Inhale...', cls:'inhale', duration:3500 },
  { label:'Hold...', cls:'hold', duration:3500 },
  { label:'Exhale...', cls:'exhale', duration:3500 }
];

function runBreathPhase(){
  if(!breathing) return;
  const phase = phases[breathePhaseIndex % phases.length];
  breatheCircle.textContent = phase.label;
  breatheCircle.classList.remove('inhale','hold','exhale');
  void breatheCircle.offsetWidth;
  breatheCircle.classList.add(phase.cls);
  breathePhaseIndex++;
  breatheTimer = setTimeout(runBreathPhase, phase.duration);
}

breatheBtn.addEventListener('click', () => {
  breathing = !breathing;
  if(breathing){
    breatheBtn.textContent = 'Stop Breathing Session';
    breathePhaseIndex = 0;
    runBreathPhase();
  } else {
    breatheBtn.textContent = 'Start Breathing Session';
    clearTimeout(breatheTimer);
    breatheCircle.classList.remove('inhale','hold','exhale');
    breatheCircle.textContent = 'Press start';
  }
});

/* ---------- Constellation Sky ---------- */
const starMessages = [
  "You are my favorite star in the universe ✨",
  "Distance means nothing when someone means everything 🌌",
  "Every night I look up, I think of you looking up too 🌠",
  "You are the calm in every storm I've ever faced 💫",
  "Out of every galaxy, I'd still pick your heart 🌟",
  "You make ordinary days feel like something worth remembering 🩷",
  "I fall for you a little more every single day 🌙",
  "Your smile is the warmest light I know ✨",
  "No matter the time zone, my heart runs on your time 🕰️",
  "You are proof that some things really are worth waiting for 🌌",
  "I'm not just falling for you, I already landed 💖",
  "You feel like home, even from miles away 🏡",
  "Every star tonight is just me thinking about you 🌠",
  "You're the softest part of my whole world 🤍",
  "I'd choose this love in every universe, every time 🌌",
  "Your voice is my favorite sound in the world 🎶",
  "You make missing someone feel worth it 💫",
  "I promise you'll never have to be strong alone 🫂",
  "You are loved more than words can hold 💕",
  "This sky is big, but my love for you is bigger 🌌",
  "You're my person, today and every day after ✨"
];
const skyCard = document.getElementById('sky-card');
function buildSky(){
  skyCard.innerHTML = '';
  const starCount = 22;
  for(let i=0;i<starCount;i++){
    const star = document.createElement('button');
    star.className = 'star';
    star.setAttribute('aria-label','star');
    star.style.left = (2 + Math.random()*94) + '%';
    star.style.top = (4 + Math.random()*88) + '%';
    star.style.animationDelay = (Math.random()*2.6) + 's';
    const size = 5 + Math.random()*7;
    star.style.width = size + 'px';
    star.style.height = size + 'px';
    const msg = starMessages[i % starMessages.length];
    star.addEventListener('click', () => openModal('A star just for you ✨', msg));
    skyCard.appendChild(star);
  }
}
buildSky();

/* ---------- Love Jar ---------- */
const loveReasons = [
  "The way you laugh at your own jokes before you even finish them.",
  "How you always check if I ate, even when you're the one having a rough day.",
  "The way you say my name when you're sleepy.",
  "Your heart is the softest, safest place I know.",
  "How you remember tiny things I mention once and bring them up weeks later.",
  "The way you get excited over small, silly things.",
  "How brave you are, even on the days you don't feel brave at all.",
  "Your voice notes that I replay more than I'd ever admit.",
  "How you make even ordinary days feel like an adventure.",
  "The way you care for the people you love, fiercely and quietly.",
  "How your bad days still make room to ask about mine.",
  "The way you say 'okay, tell me everything' and actually mean it.",
  "How you turn stress into something we can laugh about later.",
  "Your patience, even when I'm difficult.",
  "The way your eyes look when you're genuinely happy.",
  "How you never let me feel alone, even from far away.",
  "The way you believe in me on days I don't believe in myself.",
  "How you love with your whole heart, no half measures.",
  "The little rituals we've built that are just ours.",
  "How you make 'home' feel like a person instead of a place.",
  "The way you say goodnight like it actually matters to you.",
  "How you make me want to be a better person, gently, without asking."
];
document.getElementById('love-jar').addEventListener('click', () => {
  const reason = loveReasons[Math.floor(Math.random()*loveReasons.length)];
  openModal('A reason I love you 💌', reason);
  const jarBody = document.getElementById('jar-body');
  jarBody.animate([
    { transform:'scale(1)' },
    { transform:'scale(1.06)' },
    { transform:'scale(1)' }
  ], { duration:380, easing:'cubic-bezier(.34,1.56,.64,1)' });
});

/* ---------- Open When Envelopes ---------- */
const letters = {
  miss: {
    title: "Open when you miss me 💌",
    body: "Hey Pookie,\n\nIf you're reading this, it probably means the distance is sitting heavy on you right now. I want you to know something important: missing me isn't a sign that something is wrong. It's just proof of how much love is between us with nowhere to go for a moment.\n\nClose your eyes. Picture me right there next to you, holding your hand the way I always do. I'm thinking of you right now, probably more than you know. This feeling won't last forever — we're building toward a future where 'missing you' turns into 'right here with you.'\n\nUntil then, I'm only ever a message away. You are never as far from me as it feels.\n\nAll my love, always."
  },
  badday: {
    title: "Open when you had a bad day 🤍",
    body: "Hi love,\n\nI'm sorry today was hard. You don't have to explain it or make it make sense — you're allowed to just have a bad day, and I'm still proud of you for getting through it.\n\nWhatever happened, it doesn't change how I see you. You are still capable, still lovely, still my favorite person, even on the days that felt heavy and unfair.\n\nTake off whatever you're wearing that feels tight or itchy, make something warm to drink, and let yourself rest. Tomorrow gets to be different. And no matter what today looked like, you came home to someone who loves you exactly as you are.\n\nRest now, Pookie. I've got you."
  },
  insecure: {
    title: "Open when you feel insecure 💗",
    body: "My love,\n\nWhatever thought is looping in your head right now, I need you to hear this clearly: you are enough. Not almost enough, not enough-if-you-change-something — just enough, exactly as you are today.\n\nI didn't fall for a version of you that doesn't exist. I fell for the real one — the one who overthinks sometimes, who has bad hair days, who isn't always confident. That's who I choose, every single time.\n\nInsecurity lies. It tells you things that aren't true and makes you compare yourself to people who don't matter. I only see you. I only want you.\n\nYou are safe here, and you are loved here, fully and without conditions."
  },
  hug: {
    title: "Open when you want a warm hug 🫂",
    body: "Hey you,\n\nCome here. Let me hold you for a minute.\n\nImagine my arms around you right now, pulling you in close, your head resting right where it always does. No need to say anything — just breathe, and let yourself be held for a second.\n\nI wish I could actually be there to hug you properly, tight and warm, the kind that makes everything feel a little lighter. Until I can, let this letter be the next best thing.\n\nYou're safe. You're loved. You're held, even from here."
  }
};
document.querySelectorAll('.envelope').forEach(env => {
  env.addEventListener('click', () => {
    const data = letters[env.dataset.letter];
    if(data) openModal(data.title, data.body);
  });
});

/* ---------- Hug Generator ---------- */
const hugBtn = document.getElementById('hug-btn');
const confettiField = document.getElementById('hug-confetti');
function spawnConfettiHeart(){
  const h = document.createElement('div');
  h.className = 'confetti-heart';
  h.textContent = ['💖','💕','💗','✨','🤍'][Math.floor(Math.random()*5)];
  h.style.left = Math.random()*100 + 'vw';
  h.style.fontSize = (14 + Math.random()*18) + 'px';
  const duration = 2.6 + Math.random()*2;
  h.style.animationDuration = duration + 's';
  confettiField.appendChild(h);
  setTimeout(() => h.remove(), duration*1000 + 100);
}
hugBtn.addEventListener('click', () => {
  for(let i=0;i<40;i++) setTimeout(spawnConfettiHeart, i*30);
  openModal('Sending a hug 🤗', "Closing distance... Sending a tight, warm 10-second hug right now! Close your eyes and feel it 💕\n\n...\n\nThere. That was me, holding you as tight as I can from here.");
});

/* ---------- Kiss Counter ---------- */
const kissBtn = document.getElementById('kiss-btn');
const kissCountEl = document.getElementById('kiss-count');
const kissLabelEl = document.getElementById('kiss-label');
let kissCount = 0;
try {
  kissCount = parseInt(localStorage.getItem('osh_kiss_count') || '0', 10) || 0;
} catch(e) { kissCount = 0; }
kissCountEl.textContent = kissCount;

const kissMilestones = [
  [1, "your very first kiss here 🥹"],
  [10, "double digits already 💗"],
  [50, "50 kisses?! be still my heart"],
  [100, "100 kisses. I'm so lucky."],
  [365, "a whole year's worth of kisses 🐭💕"]
];
function kissLabelFor(n){
  const hit = kissMilestones.slice().reverse().find(m => n >= m[0]);
  return hit ? hit[1] : "kisses sent so far";
}
kissBtn.addEventListener('click', (e) => {
  kissCount++;
  kissCountEl.textContent = kissCount;
  kissCountEl.classList.remove('bump');
  void kissCountEl.offsetWidth;
  kissCountEl.classList.add('bump');
  kissLabelEl.textContent = kissLabelFor(kissCount);
  try { localStorage.setItem('osh_kiss_count', String(kissCount)); } catch(err) {}

  const rect = kissBtn.getBoundingClientRect();
  const pop = document.createElement('div');
  pop.className = 'kiss-pop';
  pop.textContent = ['💋','💗','💕'][Math.floor(Math.random()*3)];
  pop.style.left = (rect.left + rect.width/2 - 10 + (Math.random()*40-20)) + 'px';
  pop.style.top = (rect.top) + 'px';
  document.body.appendChild(pop);
  setTimeout(() => pop.remove(), 1000);
});

/* ---------- Countdown to Next Time ---------- */
const countdownSet = document.getElementById('countdown-set');
const countdownDisplay = document.getElementById('countdown-display');
const countdownInput = document.getElementById('countdown-input');
const countdownBtn = document.getElementById('countdown-btn');
const countdownEdit = document.getElementById('countdown-edit');
const cdDays = document.getElementById('cd-days');
const cdHours = document.getElementById('cd-hours');
const cdMins = document.getElementById('cd-mins');
const cdSecs = document.getElementById('cd-secs');
let countdownTimer = null;

function startCountdown(dateStr){
  countdownSet.style.display = 'none';
  countdownDisplay.style.display = 'block';
  clearInterval(countdownTimer);
  function tick(){
    const target = new Date(dateStr + 'T00:00:00').getTime();
    const now = Date.now();
    let diff = target - now;
    if(diff <= 0){
      cdDays.textContent = '0'; cdHours.textContent = '0'; cdMins.textContent = '0'; cdSecs.textContent = '0';
      clearInterval(countdownTimer);
      openModal("The day is here 🥹", "Today's the day, Pookie. No more counting down — I'll see you soon 💕");
      return;
    }
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    cdDays.textContent = d;
    cdHours.textContent = h;
    cdMins.textContent = m;
    cdSecs.textContent = s;
  }
  tick();
  countdownTimer = setInterval(tick, 1000);
}

try {
  const savedDate = localStorage.getItem('osh_countdown_date');
  if(savedDate){
    countdownInput.value = savedDate;
    startCountdown(savedDate);
  }
} catch(e) {}

countdownBtn.addEventListener('click', () => {
  const val = countdownInput.value;
  if(!val) return;
  try { localStorage.setItem('osh_countdown_date', val); } catch(e) {}
  startCountdown(val);
});
countdownEdit.addEventListener('click', () => {
  countdownSet.style.display = 'flex';
  countdownDisplay.style.display = 'none';
  clearInterval(countdownTimer);
});

/* ---------- Floating Mascot ---------- */
const mascotBtn = document.getElementById('mascot-btn');
const mascotBubble = document.getElementById('mascot-bubble');
const mascotLines = [
  "hi Pookie, it's me, your Little Mouse 🐭",
  "just checking in... I love you 💕",
  "you make my whole world softer 🤍",
  "tap the jar if you need a reason to smile 🫙",
  "have you had water today? drink some, love 💧",
  "I'm always just a squeak away 🐭",
  "you're doing better than you think you are 🌸",
  "sending you the biggest hug from here 🤗",
  "you are so deeply loved, Pookie 💗"
];
let mascotTimeout = null;
mascotBtn.addEventListener('click', () => {
  const line = mascotLines[Math.floor(Math.random()*mascotLines.length)];
  mascotBubble.textContent = line;
  mascotBubble.classList.add('show');
  clearTimeout(mascotTimeout);
  mascotTimeout = setTimeout(() => mascotBubble.classList.remove('show'), 4200);
});

/* ---------- Secret Passcode Vault ---------- */
const validCodes = ['52746','pookie'];
const vaultInput = document.getElementById('vault-input');
const vaultBtn = document.getElementById('vault-btn');
const vaultMsg = document.getElementById('vault-msg');

function tryUnlock(){
  const code = vaultInput.value.trim().toLowerCase();
  if(validCodes.includes(code)){
    vaultMsg.textContent = "Unlocked 🔓 Opening your letter...";
    vaultMsg.classList.remove('shake');
    setTimeout(() => {
      openModal("A promise, just for you 💛", "My darling Pookie,\n\nYou found the code — of course you did, you know me better than anyone.\n\nHere is my promise to you: I will keep choosing you, on the easy days and the hard ones. I will keep showing up, even from far away. I will keep learning how to love you better, one day at a time.\n\nI promise to celebrate your wins loudly, to sit with you through your worst days quietly, and to never let you feel like you're carrying anything alone.\n\nYou are my safe place, my favorite person, my forever choice.\n\nThis vault will always be here, waiting for you, whenever you need to remember how loved you are.\n\nAll of me, always yours — your Little Mouse 🐭", "https://media1.tenor.com/m/nisaHYy8yAYAAAAd/besito-catlove.gif");
    }, 500);
    vaultInput.value = '';
  } else {
    vaultMsg.textContent = "Wrong code! Try the secret number or your favorite nickname 🤫";
    vaultMsg.classList.remove('shake');
    void vaultMsg.offsetWidth;
    vaultMsg.classList.add('shake');
  }
}
vaultBtn.addEventListener('click', tryUnlock);
vaultInput.addEventListener('keydown', (e) => { if(e.key === 'Enter') tryUnlock(); });

/* ---------- Init ---------- */
applyMood('default');
